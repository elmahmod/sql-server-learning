# Generalization vs. Specialization — User Accounts Example

## The Core Idea

Both **generalization** and **specialization** describe an **IS-A** hierarchy in an ERD. They can produce **the same final diagram**; the difference is **where we start during database design**.

![Generalization and Specialization using User, Student, Teacher, and Admin](./user_accounts_generalization_specialization.png)

## 1. Generalization (Bottom-Up)

Imagine we already have three entities in a system:

| Entity | Specific Attribute | Shared Attributes |
|---|---|---|
| `Student` | `StudentNumber` | `Id`, `Name`, `Email`, `PasswordHash` |
| `Teacher` | `Subject` | `Id`, `Name`, `Email`, `PasswordHash` |
| `Admin` | `PermissionLevel` | `Id`, `Name`, `Email`, `PasswordHash` |

We notice that all three entities share the same basic account information.

**Solution:** Create a more general entity called `User`, move the shared attributes into it, and keep the specific attributes in their respective subtypes.

**Thought process:** `Student` + `Teacher` + `Admin` → discover `User`.

> **Generalization:** Start with specific entities and extract what they have in common.

## 2. Specialization (Top-Down)

Now imagine we are designing the system from scratch.

We begin with one general entity, **`User`**, containing:

- `Id` (identifier)
- `Name`
- `Email`
- `PasswordHash`

Then we realize that different users need different information:

- **`Student`** needs `StudentNumber`.
- **`Teacher`** needs `Subject`.
- **`Admin`** needs `PermissionLevel`.

**Solution:** Specialize `User` into the three subtypes.

**Thought process:** `User` → define `Student`, `Teacher`, and `Admin`.

> **Specialization:** Start with a general entity and divide it into more specific entities.

## 3. Quick Comparison

| | Generalization | Specialization |
|---|---|---|
| Direction of design | Bottom-Up ↑ | Top-Down ↓ |
| Starting point | Specific entities | General entity |
| Main question | What do they share? | How are they different? |
| Example | `Student`, `Teacher`, `Admin` → `User` | `User` → `Student`, `Teacher`, `Admin` |
| Final ERD | IS-A hierarchy | The same IS-A hierarchy |

## 4. Connection to OOP Inheritance

If you know C# inheritance, the result looks familiar:

```csharp
class User
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
}

class Student : User
{
    public string StudentNumber { get; set; }
}

class Teacher : User
{
    public string Subject { get; set; }
}

class Admin : User
{
    public int PermissionLevel { get; set; }
}
```

The **IS-A** relationship is similar: `Student` **is a** `User`, `Teacher` **is a** `User`, and `Admin` **is a** `User`.

**Important:** In OOP, inheritance involves classes and behavior. In an ERD, generalization/specialization describes data entities and their common and specific attributes. The design process is not determined by the direction a triangle happens to point in a diagram.

## 5. Remember

- **Generalization = group shared attributes.**
- **Specialization = split an entity into specific types.**
- **The resulting hierarchy may be identical.**

---

**GitHub image note:** Keep this Markdown file and `user_accounts_generalization_specialization.png` in the **same directory** so the relative image link works.
